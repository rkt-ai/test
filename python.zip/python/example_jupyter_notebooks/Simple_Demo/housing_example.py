# Importing Necessary Libraries
## Standard libraries
import pandas as pd
import numpy as np
## Turn off warnings to save page space
pd.options.mode.chained_assignment = None  # default='warn'
import warnings
from sklearn.exceptions import DataConversionWarning
warnings.filterwarnings(action='ignore', category=DataConversionWarning)
## pyaugment Libraries
import pyaugment as aug
import utilfuncs as util
import regfuncs as reg

# Writing out CTGAN for Housing
def Augmentation_Housing(path_to_data,table_name,aug_method,primary_key,
                         batch_size,epochs,encode_col):

    # Read in data and clean
    df = util.read_data(path_to_data)
    df = util.id_row(df)
    df = df.dropna()
    df = df.drop(['longitude', 'latitude'], axis  = 1)
    train, test, val = util.traintestval_split(df, with_val = True)
    train_metadata = aug.get_metadata(train, table_name, primary_key)

    Aug_Model = aug.Augment_model(method = aug_method,
                                  df = train,
                                  primary_key = primary_key,
                                  field_types = train_metadata,
                                  batch_sze = batch_size,
                                  epochs = epochs)

    Aug_Data = aug.sample(model = Aug_Model,
                          num_rows = round(train.shape[0]*.5/10)*10,
                          batch_size = batch_size,
                          randomize_samples = False)

    # Chi-Square Test and Kolmogorov-Smirnov Test Metrics
    simularity = aug.evaluate_statmetrics(Aug_Data, train, 'CS_KS')

    # Create Augmented Train Dataset
    train_aug = aug.Augmented_DF(train, Aug_Data) 
    
    ## Balance the augmented train dataset
    # nearbay_num_rows = (train_aug[encode_col]=='<1H OCEAN').sum()-(train_aug[encode_col]=='NEAR BAY').sum()
    # inland_num_rows = (train_aug[encode_col]=='<1H OCEAN').sum()-(train_aug[encode_col]=='INLAND').sum()
    # island_num_rows = (train_aug[encode_col]=='<1H OCEAN').sum()-(train_aug[encode_col]=='ISLAND').sum()
    # nearocean_num_rows = (train_aug[encode_col]=='<1H OCEAN').sum()-(train_aug[encode_col]=='NEAR OCEAN').sum()

    # nearbay_dict = {'ocean_proximity':'NEAR BAY'}
    # inland_dict = {'ocean_proximity':'INLAND'}
    # island_dict = {'ocean_proximity':'ISLAND'}
    # nearocean_dict = {'ocean_proximity':'NEAR OCEAN'}
    
    # nearbay_aug = aug.conditionally_sample(Aug_Model, nearbay_dict, nearbay_num_rows, batch_size)
    # inland_aug = aug.conditionally_sample(Aug_Model, inland_dict, inland_num_rows, batch_size)
    # island_aug = aug.conditionally_sample(Aug_Model, island_dict, island_num_rows, batch_size)
    # nearocean_aug = aug.conditionally_sample(Aug_Model, nearocean_dict, nearocean_num_rows, batch_size)

    # df_bal

    


    return train, test, val, simularity, train_aug, 